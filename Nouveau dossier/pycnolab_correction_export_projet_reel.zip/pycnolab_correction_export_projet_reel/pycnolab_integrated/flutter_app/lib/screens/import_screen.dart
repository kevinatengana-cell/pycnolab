﻿import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/gamme_request.dart';
import '../models/resultat_gamme.dart';
import '../services/history_service.dart';
import '../services/python_engine_service.dart';
import 'resultats_screen.dart';

class ImportScreen extends StatefulWidget {
  final GammeRequest? configInitiale;
  final String typeEssai;

  const ImportScreen({super.key, this.configInitiale, this.typeEssai = 'traction'});

  @override
  State<ImportScreen> createState() => _ImportScreenState();
}

class _ImportScreenState extends State<ImportScreen> {
  final PythonEngineService _pythonService = PythonEngineService();
  bool _isLoading = false;
  String? _cheminFichierSelectionne;
  String? _nomFichierSelectionne;

  Future<void> _choisirFichier() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );
    if (result == null || result.files.single.path == null || !mounted) return;
    setState(() {
      _cheminFichierSelectionne = result.files.single.path!;
      _nomFichierSelectionne = result.files.single.name;
    });
  }

  Future<void> _calculerEtAfficher() async {
    final chemin = _cheminFichierSelectionne;
    if (chemin == null) {
      _afficherErreur('Sélectionnez d’abord le fichier Excel de l’essai.');
      return;
    }
    setState(() => _isLoading = true);
    try {
      final raw = await _pythonService.calculerDepuisExcel(chemin, widget.configInitiale);
      final donnees = raw is Map<String, dynamic>
          ? raw
          : Map<String, dynamic>.from(raw as Map);
      final resultat = ResultatGamme.fromJson(donnees);
      HistoryService.instance.add(resultat);
      if (!mounted) return;
      setState(() => _isLoading = false);
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultatsScreen(
            donnees: donnees,
            cheminFichierSource: chemin,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _afficherErreur('Calcul impossible : $e');
    }
  }

  void _afficherErreur(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }

  @override
  Widget build(BuildContext context) {
    final titre = widget.typeEssai == 'compression'
        ? 'Essai de compression'
        : 'Essai de traction';
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        title: const Text('PYCNOLAB — Import de l’essai'),
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: Card(
              color: const Color(0xFF1E293B),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(titre, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    const Text('Sélectionnez le classeur complet contenant les diamètres et les mesures Elong/Force.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF94A3B8))),
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(color: const Color(0xFF0F172A), borderRadius: BorderRadius.circular(12)),
                      child: Row(children: [
                        const Icon(Icons.table_chart_outlined, color: Color(0xFF60A5FA), size: 34),
                        const SizedBox(width: 14),
                        Expanded(child: Text(_nomFichierSelectionne ?? 'Aucun fichier sélectionné', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
                      ]),
                    ),
                    const SizedBox(height: 20),
                    OutlinedButton.icon(
                      onPressed: _isLoading ? null : _choisirFichier,
                      icon: const Icon(Icons.file_open_outlined),
                      label: const Text('Sélectionner le fichier Excel'),
                    ),
                    const SizedBox(height: 12),
                    if (_isLoading)
                      const Column(children: [CircularProgressIndicator(), SizedBox(height: 12), Text('Calcul des résultats par le moteur Python...', style: TextStyle(color: Color(0xFFCBD5E1)))])
                    else
                      ElevatedButton.icon(
                        onPressed: _cheminFichierSelectionne == null ? null : _calculerEtAfficher,
                        icon: const Icon(Icons.calculate_outlined),
                        label: const Text('Calculer et afficher les résultats'),
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2563EB), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 15)),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
