from __future__ import annotations

from pathlib import Path
from statistics import mean
from openpyxl import load_workbook


OUTPUT_SHEETS = [
    "DIAMETRE (CR,CS)",
    "COROUI",
    "COSOU",
    "RECCAPITULATIF",
]
GROUP_SHEETS = ["COROUI", "COSOU"]
BLOCK_WIDTH = 8  # 7 colonnes de calcul + 1 séparation


def _safe_float(value):
    return None if value is None else float(value)


def _write_diameter_group(ws, start_col: int, samples: list[dict], last_row: int = 24) -> None:
    """Remplit un bloc diamètre du modèle sans détruire ses styles."""
    for offset, label in enumerate(
        ["D_1(mm)", "D_2(mm)", "D_3(mm)", "D_Moy(mm)", "S_(mm2)", "D_Moy Global(mm)"],
    ):
        ws.cell(2, start_col + offset).value = label

    for index in range(last_row - 2 + 1):
        row = 3 + index
        if index < len(samples):
            sample = samples[index]
            ws.cell(row, start_col - 1).value = sample["identifiant"]
            values = sample.get("diametres_mm", [])[:3]
            for offset in range(3):
                ws.cell(row, start_col + offset).value = values[offset] if offset < len(values) else None
            ws.cell(row, start_col + 3).value = f"=AVERAGE({ws.cell(row, start_col).coordinate}:{ws.cell(row, start_col + 2).coordinate})"
            ws.cell(row, start_col + 4).value = f"=3.14*{ws.cell(row, start_col + 3).coordinate}*{ws.cell(row, start_col + 3).coordinate}/4"
        else:
            ws.cell(row, start_col - 1).value = None
            for offset in range(5):
                ws.cell(row, start_col + offset).value = None

    first = 3
    last = 2 + len(samples)
    if samples:
        ws.cell(3, start_col + 5).value = f"=AVERAGE({ws.cell(first, start_col + 3).coordinate}:{ws.cell(last, start_col + 3).coordinate})"
    else:
        ws.cell(3, start_col + 5).value = None


def _sample_blocks(ws):
    return [(1 + index * BLOCK_WIDTH, 2 + index * BLOCK_WIDTH) for index in range(22)]


def _write_curve_sheet(ws, samples: list[dict], diameter_col: str, l0_mm: float) -> None:
    """Remplit les blocs existants du modèle et conserve ses graphiques."""
    blocks = _sample_blocks(ws)
    for index, (elong_col, force_col) in enumerate(blocks):
        if index >= len(samples):
            continue
        sample = samples[index]
        points = sample.get("points_courbe", [])
        if not points:
            continue
        first_row = 2
        last_row = first_row + len(points) - 1
        diam_row = 3 + index
        section_ref = f"'DIAMETRE (CR,CS)'!${diameter_col}${diam_row}"

        # Nettoyage limité au bloc utile afin de ne pas déplacer la mise en page.
        for row in range(2, max(ws.max_row, last_row) + 1):
            for col in range(elong_col, elong_col + 7):
                if row > last_row or col in (elong_col + 4, elong_col + 5, elong_col + 6):
                    if row != 2 or col not in (elong_col + 4, elong_col + 5, elong_col + 6):
                        ws.cell(row, col).value = None

        for point_index, point in enumerate(points):
            row = first_row + point_index
            ws.cell(row, elong_col).value = _safe_float(point["deplacement_mm"])
            ws.cell(row, force_col).value = _safe_float(point["force_newton"])
            ws.cell(row, elong_col + 2).value = f"={ws.cell(row, elong_col).coordinate}/{l0_mm}"
            ws.cell(row, elong_col + 3).value = f"={ws.cell(row, force_col).coordinate}/{section_ref}"

        max_cell = ws.cell(2, elong_col + 4)
        rupture_cell = ws.cell(2, elong_col + 5)
        young_cell = ws.cell(2, elong_col + 6)
        stress_first = ws.cell(first_row, elong_col + 3).coordinate
        stress_last = ws.cell(last_row, elong_col + 3).coordinate
        strain_first = ws.cell(first_row, elong_col + 2).coordinate
        strain_last = ws.cell(last_row, elong_col + 2).coordinate
        max_cell.value = f"=MAX({stress_first}:{stress_last})"
        rupture_cell.value = f"=INDEX({strain_first}:{strain_last},MATCH({max_cell.coordinate},{stress_first}:{stress_last},0))"
        young_cell.value = f"=SLOPE({stress_first}:{stress_last},{strain_first}:{strain_last})"

    # Le modèle possède 22 graphiques par gamme. On ne supprime que les éventuels
    # graphiques excédentaires si le fichier contient moins de 22 échantillons.
    while len(ws._charts) > len(samples):
        ws._charts.pop()


def process_workbook(input_path: str | Path, template_path: str | Path, output_path: str | Path, l0_mm: float = 20.0) -> Path:
    from ..import_excel.reader import read_workbook

    data = read_workbook(input_path)
    groups = {item["nom_gamme"]: item for item in data["gammes"]}
    missing = [name for name in GROUP_SHEETS if name not in groups]
    if missing:
        raise ValueError(f"Gammes absentes du fichier d'entrée : {', '.join(missing)}")

    wb = load_workbook(template_path, data_only=False)
    for name in list(wb.sheetnames):
        if name not in OUTPUT_SHEETS:
            wb.remove(wb[name])

    diam = wb["DIAMETRE (CR,CS)"]
    _write_diameter_group(diam, 2, groups["COROUI"]["echantillons"])
    _write_diameter_group(diam, 10, groups["COSOU"]["echantillons"])
    _write_curve_sheet(wb["COROUI"], groups["COROUI"]["echantillons"], "F", l0_mm)
    _write_curve_sheet(wb["COSOU"], groups["COSOU"]["echantillons"], "N", l0_mm)

    # Le récapitulatif du modèle contient déjà ses formules et ses 3 graphiques.
    # Les références restent valides car les blocs des deux gammes sont conservés.
    recap = wb["RECCAPITULATIF"]
    while len(recap._charts) > 3:
        recap._charts.pop()

    try:
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
        wb.calculation.calcMode = "auto"
    except AttributeError:
        pass

    output = Path(output_path)
    wb.save(output)
    return output
