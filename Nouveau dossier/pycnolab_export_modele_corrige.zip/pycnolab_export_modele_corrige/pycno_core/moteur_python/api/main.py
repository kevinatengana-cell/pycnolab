from io import BytesIO
from pathlib import Path
from typing import Optional, List, Dict, Any
import traceback
import os
import tempfile

import openpyxl
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field
from fastapi.middleware.cors import CORSMiddleware

from ..import_excel.reader import lire_gamme_complete
from ..export_excel.production_workbook_exporter import process_workbook
from moteur_python.calculs.traction import TractionCalculateur
from moteur_python.modeles.models import (
    ConditionsAmbiantes,
    Echantillon,
    FamilleMateriau,
    Gamme,
    Materiau,
    Norme,
    PointCourbe,
)

app = FastAPI(title="PycnoLab Engine API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==========================================
# MODÈLES DE REQUÊTES (MATCHING FLUTTER & READER)
# ==========================================

class MateriauRequest(BaseModel):
    nom_usage: str
    code_interne: str
    famille: str = "autre"


class NormeRequest(BaseModel):
    code: str
    designation: str
    seuil_resistance_min_mpa: Optional[float] = None
    seuil_allongement_min_pourcent: Optional[float] = None


class ConditionsRequest(BaseModel):
    temperature_celsius: Optional[float] = None
    humidite_pourcent: Optional[float] = None
    duree_conditionnement_heures: Optional[float] = None


class PointCourbeRequest(BaseModel):
    force_newton: float
    deplacement_mm: float


class EchantillonRequest(BaseModel):
    identifiant: str
    longueur_initiale_mm: float = 20.0
    largeur_mm: Optional[float] = None
    epaisseur_mm: Optional[float] = None
    diametres_mm: List[float] = Field(default_factory=list)
    force_rupture_newton: Optional[float] = None
    deplacement_rupture_mm: Optional[float] = None
    points_courbe: List[PointCourbeRequest] = Field(default_factory=list)
    parametres_extra: Dict[str, float] = Field(default_factory=dict)


class GammeRequest(BaseModel):
    materiau: MateriauRequest
    norme: NormeRequest
    conditions: Optional[ConditionsRequest] = None
    echantillons: List[EchantillonRequest] = Field(default_factory=list)
    calculs_demandes: List[str] = Field(default_factory=list)


class ImportExcelRequest(BaseModel):
    chemin_fichier: str
    materiau: Optional[MateriauRequest] = None
    norme: Optional[NormeRequest] = None
    conditions: Optional[ConditionsRequest] = None
    calculs_demandes: List[str] = Field(default_factory=list)


class ExporterExcelRequest(BaseModel):
    chemin_fichier: str
    l0_mm: float = 20.0


# ==========================================
# CONVERTISSEURS DOMAINE
# ==========================================

def _famille_enum(famille: str) -> FamilleMateriau:
    mapping = {item.value: item for item in FamilleMateriau}
    return mapping.get(str(famille).lower(), FamilleMateriau.AUTRE)


def _to_domain_gamme(gamme: GammeRequest) -> Gamme:
    cond_temp = gamme.conditions.temperature_celsius if gamme.conditions else None
    cond_hum = gamme.conditions.humidite_pourcent if gamme.conditions else None
    cond_dur = gamme.conditions.duree_conditionnement_heures if gamme.conditions else None

    return Gamme(
        materiau=Materiau(
            nom_usage=gamme.materiau.nom_usage,
            code_interne=gamme.materiau.code_interne,
            famille=_famille_enum(gamme.materiau.famille),
        ),
        norme=Norme(
            code=gamme.norme.code,
            designation=gamme.norme.designation,
            seuil_resistance_min_mpa=gamme.norme.seuil_resistance_min_mpa,
            seuil_allongement_min_pourcent=gamme.norme.seuil_allongement_min_pourcent,
        ),
        conditions=ConditionsAmbiantes(
            temperature_celsius=cond_temp,
            humidite_pourcent=cond_hum,
            duree_conditionnement_heures=cond_dur,
        ),
        echantillons=[
            Echantillon(
                identifiant=e.identifiant,
                longueur_initiale_mm=e.longueur_initiale_mm,
                largeur_mm=e.largeur_mm,
                epaisseur_mm=e.epaisseur_mm,
                diametres_mm=e.diametres_mm,
                force_rupture_newton=e.force_rupture_newton,
                deplacement_rupture_mm=e.deplacement_rupture_mm,
                points_courbe=[
                    PointCourbe(
                        force_newton=p.force_newton,
                        deplacement_mm=p.deplacement_mm,
                    )
                    for p in e.points_courbe
                ],
            )
            for e in gamme.echantillons
        ],
        calculs_demandes=gamme.calculs_demandes,
    )


# ==========================================
# ENDPOINTS API
# ==========================================

@app.get('/health')
def health() -> dict[str, str]:
    return {
        'status': 'ok',
        'service': 'pycnolab-engine',
        'protocol': '1',
    }


@app.post("/essais/traction/calculer")
def calculer_traction(gamme: GammeRequest) -> dict:
    domaine = _to_domain_gamme(gamme)
    resultat = TractionCalculateur().calculer(domaine)

    resultats = []
    for r, ech in zip(resultat.resultats_echantillons, resultat.gamme.echantillons):
        try:
            section_val = ech.section_mm2()
        except Exception:
            section_val = None

        resultats.append(
            {
                "identifiant": r.identifiant,
                "contrainte_rupture_mpa": r.contrainte_rupture_mpa,
                "deformation_rupture_pourcent": r.deformation_rupture_pourcent,
                "module_young_mpa": r.module_young_mpa,
                "energie_rupture_joules": r.energie_rupture_joules,
                "limite_elastique_mpa": r.limite_elastique_mpa,
                "longueur_initiale_mm": ech.longueur_initiale_mm,
                "largeur_mm": ech.largeur_mm,
                "epaisseur_mm": ech.epaisseur_mm,
                "diametres_mm": ech.diametres_mm,
                "force_rupture_newton": ech.force_rupture_newton,
                "deplacement_rupture_mm": ech.deplacement_rupture_mm,
                "points_courbe": [{"force_newton": p.force_newton, "deplacement_mm": p.deplacement_mm} for p in ech.points_courbe],
                "section_mm2": section_val,
            }
        )

    deformations = [r.deformation_rupture_pourcent for r in resultat.resultats_echantillons if r.deformation_rupture_pourcent is not None]
    epsilon_moyen = float(sum(deformations) / len(deformations)) if deformations else 0.0

    statistiques = {
        "sigma_moyenne": resultat.resistance_moyenne_mpa,
        "sigma_ecart_type": resultat.ecart_type_mpa,
        "epsilon_moyen": epsilon_moyen,
        "epsilon_ecart_type": resultat.ecart_type_deformation_pourcent,
        "module_young_ecart_type_mpa": resultat.ecart_type_module_young_mpa,
    }

    return {
        "materiau_nom": resultat.gamme.materiau.nom_usage,
        "norme_code": resultat.gamme.norme.code,
        "horodatage": resultat.gamme.horodatage.isoformat(),
        "resultats_echantillons": resultats,
        "echantillons": resultats,
        "statistiques": statistiques,
        "resistance_moyenne_mpa": resultat.resistance_moyenne_mpa,
        "ecart_type_mpa": resultat.ecart_type_mpa,
        "module_young_moyen_mpa": resultat.module_young_moyen_mpa,
        "ecart_type_module_young_mpa": resultat.ecart_type_module_young_mpa,
        "deformation_moyenne_pourcent": resultat.deformation_moyenne_pourcent,
        "ecart_type_deformation_pourcent": resultat.ecart_type_deformation_pourcent,
        "energie_rupture_moyenne_joules": resultat.energie_rupture_moyenne_joules,
        "limite_elastique_moyenne_mpa": resultat.limite_elastique_moyenne_mpa,
        "statut": resultat.statut.value,
    }


@app.post("/essais/traction/calculer-depuis-excel")
def calculer_depuis_excel(requete: ImportExcelRequest):
    fichier = Path(requete.chemin_fichier)
    if not fichier.exists():
        raise HTTPException(status_code=404, detail=f"Fichier introuvable : {fichier}")

    try:
        donnees = lire_gamme_complete(str(fichier))
    except Exception as e:
        tb = traceback.format_exc()
        return Response(
            content=f"ERREUR LECTURE EXCEL (reader.py):\n{type(e).__name__}: {str(e)}\n\n{tb}",
            status_code=500,
            media_type="text/plain"
        )

    try:
        if requete.materiau is not None:
            donnees["materiau"] = requete.materiau.model_dump()
        if requete.norme is not None:
            donnees["norme"] = requete.norme.model_dump()
        if requete.conditions is not None:
            donnees["conditions"] = requete.conditions.model_dump()
        if requete.calculs_demandes:
            donnees["calculs_demandes"] = requete.calculs_demandes

        gamme = GammeRequest.model_validate(donnees)
    except Exception as e:
        tb = traceback.format_exc()
        return Response(
            content=f"ERREUR VALIDATION PYDANTIC (GammeRequest):\n{type(e).__name__}: {str(e)}\n\n{tb}",
            status_code=500,
            media_type="text/plain"
        )

    try:
        return calculer_traction(gamme)
    except Exception as e:
        tb = traceback.format_exc()
        return Response(
            content=f"ERREUR MOTEUR DE CALCUL (calculer_traction):\n{type(e).__name__}: {str(e)}\n\n{tb}",
            status_code=500,
            media_type="text/plain"
        )


@app.post("/essais/traction/exporter-excel")
def exporter_excel_classeur(requete: ExporterExcelRequest) -> Response:
    fichier = Path(requete.chemin_fichier)
    if not fichier.is_file():
        raise HTTPException(status_code=404, detail=f"Fichier introuvable : {fichier}")

    # Le modèle est distribué avec le moteur, dans moteur_python/modeles.
    modele = Path(__file__).resolve().parents[1] / "modeles" / "MODELE_TRACTION.xlsx"
    if not modele.is_file():
        raise HTTPException(
            status_code=500,
            detail=f"Modèle Excel de traction introuvable : {modele}",
        )

    fd, temp_name = tempfile.mkstemp(prefix="pycnolab_", suffix=".xlsx")
    os.close(fd)
    sortie = Path(temp_name)
    try:
        process_workbook(
            input_path=fichier,
            template_path=modele,
            output_path=sortie,
            l0_mm=requete.l0_mm,
        )
        contenu = sortie.read_bytes()
        return Response(
            content=contenu,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=RAPPORT_TRACTION.xlsx"},
        )
    except Exception as e:
        tb = traceback.format_exc()
        return Response(
            content=f"ERREUR EXPORT MODELE TRACTION:\n{type(e).__name__}: {str(e)}\n\n{tb}",
            status_code=500,
            media_type="text/plain",
        )
    finally:
        try:
            sortie.unlink(missing_ok=True)
        except OSError:
            pass


@app.post("/essais/traction/export-excel")
def export_excel_legacy(gamme: GammeRequest, type_graphique: str = "barres") -> Response:
    del type_graphique
    domaine = _to_domain_gamme(gamme)
    resultat = TractionCalculateur().calculer(domaine)

    workbook = openpyxl.Workbook()
    worksheet = workbook.active
    worksheet.title = "Résultats"
    worksheet.append(["Échantillon", "Contrainte (MPa)", "Déformation (%)", "Module (MPa)"])

    for item in resultat.resultats_echantillons:
        worksheet.append([
            item.identifiant,
            item.contrainte_rupture_mpa,
            item.deformation_rupture_pourcent,
            item.module_young_mpa,
        ])

    buffer = BytesIO()
    workbook.save(buffer)
    buffer.seek(0)

    return Response(
        content=buffer.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=PV.xlsx"},
    )