import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart' show kDebugMode;
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as path;

class BackendLauncherService {
  static const _healthUrl = 'http://127.0.0.1:8123/health';
  Process? _process;

  Future<bool> _estDejaActif() async {
    try {
      final response = await http.get(Uri.parse(_healthUrl)).timeout(const Duration(seconds: 1));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  Future<void> demarrer({void Function(String message)? onStatus}) async {
    void status(String message) => onStatus?.call(message);
    status('Interface Flutter prête. Connexion au moteur Python...');
    if (await _estDejaActif()) {
      status('Moteur Python déjà actif.');
      return;
    }

    if (kDebugMode) {
      status('Lancement du moteur Python depuis python_engine...');
      await _demarrerEnDev();
    } else {
      status('Lancement du backend embarqué...');
      await _demarrerEnProd();
    }
    await _attendrePret(onStatus: status);
    status('Connexion établie avec le moteur Python.');
  }

  Future<void> _demarrerEnDev() async {
    if (!(Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      throw UnsupportedError('Le lancement local par sous-processus est réservé au desktop.');
    }
    final pythonRoot = path.normalize(path.join(Directory.current.path, '..', 'python_engine'));
    final python = Platform.isWindows
        ? path.join(pythonRoot, '.venv', 'Scripts', 'python.exe')
        : path.join(pythonRoot, '.venv', 'bin', 'python');
    if (!File(python).existsSync()) {
      throw Exception('Python introuvable : $python. Créez python_engine/.venv et installez les dépendances.');
    }
    _process = await Process.start(
      python,
      ['-m', 'uvicorn', 'main:app', '--host', '127.0.0.1', '--port', '8123'],
      workingDirectory: pythonRoot,
      runInShell: false,
    );
    _process!.stdout.listen(stdout.add);
    _process!.stderr.listen(stderr.add);
  }

  Future<void> _demarrerEnProd() async {
    final backendDir = path.join(path.dirname(Platform.resolvedExecutable), 'backend');
    final executable = Platform.isWindows ? 'pycnolab_engine.exe' : 'pycnolab_engine';
    final executablePath = path.join(backendDir, executable);
    if (!File(executablePath).existsSync()) {
      throw Exception('Backend embarqué introuvable : $executablePath');
    }
    _process = await Process.start(executablePath, [], runInShell: false);
  }

  Future<void> _attendrePret({required void Function(String message) onStatus}) async {
    for (var attempt = 1; attempt <= 30; attempt++) {
      if (await _estDejaActif()) return;
      onStatus('En attente du moteur Python... ($attempt/30)');
      await Future.delayed(const Duration(milliseconds: 500));
    }
    throw TimeoutException('Le moteur Python n’a pas répondu après 15 secondes.');
  }

  void arreter() {
    _process?.kill();
    _process = null;
  }
}
